# defining global variables
x1 = "wajahat ali"
def myfun():
    print("My name is " + x1)

myfun()

# defining variables inside function(local variables)
def name():
    x2 = "M* Arshad"
    print("My father name is " + x2)
name()

#This will executes global variables value
print("This is " + x1)


    #__________________BEST OF LUCK ____________________#