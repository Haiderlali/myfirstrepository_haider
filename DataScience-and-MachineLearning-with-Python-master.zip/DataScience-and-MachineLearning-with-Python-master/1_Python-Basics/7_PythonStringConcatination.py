
# String concatination (space include in length)
x = "Wajahat"
y = " What are you doing" # space at start
z = x + y 
print(z)

# String concatination with space between them
x = "Wajahat"
y = "What are you doing"
z = x + " " + y 
print(z)


#__________________BEST OF LUCK ____________________#