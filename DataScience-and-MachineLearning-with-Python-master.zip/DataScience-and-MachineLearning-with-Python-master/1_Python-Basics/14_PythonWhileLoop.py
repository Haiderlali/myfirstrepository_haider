# Python has two primitive loop
# 1) while
# 2) for 

# While loop
i = 1
while i < 6:
    print(i)
    i = i + 1 # same as i += 1

# Break statement stop the loop
i = 1
while i < 6:
    print(i)
    if i == 3:
        break
    i += 1

# Continue statement

i = 0
while i < 6:
    i += 1
    if i == 3:
        continue
    print(i)

# The else statement 
i = 1
while i < 6:
    print(i)
    i = i + 1 
else:
    print("i is no longer less than 6")



#__________________BEST OF LUCK ____________________#













