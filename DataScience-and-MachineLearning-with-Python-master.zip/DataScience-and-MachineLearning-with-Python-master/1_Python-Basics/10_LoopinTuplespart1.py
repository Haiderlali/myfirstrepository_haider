x = ("banana" , "orange" , "apple" , "mangoes")
for i in x:
    print(i)

# Looping through the index numbers  

x = ("banana" , "orange" , "apple" , "mangoes")
for i in range(len(x)):
    print(x[i])

# Using it by while loop

x = ("banana" , "orange" , "apple" , "mangoes")
i = 0
while i<len(x):
    print(x[i])
    i = i + 1

#__________________BEST OF LUCK ____________________#

