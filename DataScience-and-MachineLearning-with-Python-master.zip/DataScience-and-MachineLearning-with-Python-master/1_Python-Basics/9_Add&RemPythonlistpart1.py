# Adding method
# Append() : add element at last only
x = ["Banana" , "orange" , "apple" , "mangoes" , "gava"]
x.append("Cherry")
print(x)
# Insert() : add element using indexes to anywhere
x = ["Banana" , "orange" , "apple" , "mangoes" , "gava"]
x.insert(1,"pineapple")
print(x)
# Extend()
x = ["Banana" , "orange" , "apple" , "mangoes" , "gava"]
y = ['Banana', 'pineapple', 'orange', 'apple', 'mangoes', 'gava']
x.extend(y)
print(x)
# Remove list items
x=['Banana', 'pineapple', 'orange', 'apple', 'mangoes', 'gava']
x.remove("gava")
print(x)
# Reemove specified index
x = ['Banana', 'pineapple', 'orange', 'apple', 'mangoes', 'gava']
x.pop(4)
print(x)
# Remove Last Index without knowing the length
v = ['Banana', 'pineapple', 'orange', 'apple', 'mangoes', 'gava']
v.pop()
print(v)
# using Del for specified index
x = ['Banana', 'pineapple', 'orange', 'apple', 'mangoes', 'gava']
del x[0]
print(x)
# Deleting the list completely
x = ['Banana', 'pineapple', 'orange', 'apple', 'mangoes', 'gava']
del x
# Clear the list method
x = ['Banana', 'pineapple', 'orange', 'apple', 'mangoes', 'gava']
x.clear()
print(x)


#__________________BEST OF LUCK ____________________#













