
# Joining two tuples 
x = ("banana" , "orange" , "apple" , "mangoes")
y = (1 , 2 , 4 , 9 , 10)
z = x + y
print(z)

# Multiply of two tuples 

x = ("banana" , "orange" , "apple" , "mangoes")

multi = x * 2
print(multi)

# Tuples methods:
 
# count()
# index()


#__________________BEST OF LUCK ____________________#












