
'''x = "orange"
y = "banana"
z = "apple"
print(x)
print(y)
print(z)


print("****************************************")

x , y , z = "orange" , "banana" , "apple"
print(x)
print(y)
print(z)
'''




# Assign same fruit value to multiple variables

'''x = "orange"
y = "orange"
z = "orange"
print(x)
print(y)
print(z)

print("****************************************")

x = y = z = "orange"
print(x)
print(y)
print(z) '''

fruits = ["orange" , "banana" , "apple"]
x , y , z = fruits
print(x)
print(y)
print(z)


# Output variables 
y = "My name is ALI"
print(y)

x = "My"
y = "Name"
z = "is wajahat"

print(x , y ,z)

x = "My "
y = "Name "
z = "is wajahat"

print(x + y + z)

x = 5
y = 10
z = 4

print(x + y + z)

#__________________BEST OF LUCK ____________________#