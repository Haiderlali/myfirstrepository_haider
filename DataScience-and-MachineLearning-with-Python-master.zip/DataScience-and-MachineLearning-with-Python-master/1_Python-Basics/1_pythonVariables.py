
'''x = 5 
y = "Wajahat"
print(x)
print(y)
x = str(5)  # x will be "5"
y = int(5)  # x will be 5
z = float(5) # x will be 5.0
print(x)
print(y)
print(z)

# Get the type (Case-sensitive variables)
x = 5
y = "wajahat"
print(type(x))
print(type(y))

# overiding (This will executed the last entered value)
x = 5
x = "wajahat"

print(x) 

# Indentation error

if 5 > 2:
  print("Ok 5 is greater than 2")
'''
# legal variables Name you should learn:

myvar = "wajahat"
my_var = "wajahat"
_myvar = "wajahat"
_my_var = "wajahat"
MYVAR = "wajahat"
myVar = "wajahat"
myVar_2 = "wajahat"
MyVar = "wajahat"
Myvar = 12
my_var_ = "waj"
print(myvar)
print(my_var)
print(_myvar)
print(_my_var)
print(MYVAR)
print(myVar)
print(myVar_2)
print(MyVar)
print(Myvar)
print(my_var_)

'''
# Not legal variable names:
2myvar = "wajahat"
my-var = "wajahat"
my var = "wajahat" '''


'''
def find_max(nums):
    
    max_num = float("-inf")

   for num in nums:
   if num > max_num: 

print("The greater is"+ num)

return max_num'''

#__________________BEST OF LUCK ____________________#