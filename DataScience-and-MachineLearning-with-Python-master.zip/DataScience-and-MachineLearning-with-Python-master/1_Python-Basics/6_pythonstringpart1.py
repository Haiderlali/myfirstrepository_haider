# Slicing a string
a = "Wajahat Ali"
print(a[2:5])

# Slicing from start
a = "Wajahat Ali"
print(a[:5])

# Slicing from End
a = "Wajahat Ali"
print(a[5:])

# Negative Indexing 
a = "Hello world!"
print(a[-7:-1])

#__________________BEST OF LUCK ____________________#