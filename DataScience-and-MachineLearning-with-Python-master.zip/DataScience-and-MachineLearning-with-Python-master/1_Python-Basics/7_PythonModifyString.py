
# Upper case 
x = "my name is wajahat and my father name is arshad"
print(x.upper())

#Lowercase
x = "MY NAME IS WAJAHAT AND MY FATHER NAME IS ARSHAD"
print(x.lower())

# Removing Whitespace

x = "   Wajahat, Ali "
print(x.strip())  

# Replace string 

x = "This is data  science tutorials"
print(x.replace("This" , "Bahi"))

# Split string 

x = "This, is, data , science, tutorials"
print(x.split(","))


#__________________BEST OF LUCK ____________________#

















