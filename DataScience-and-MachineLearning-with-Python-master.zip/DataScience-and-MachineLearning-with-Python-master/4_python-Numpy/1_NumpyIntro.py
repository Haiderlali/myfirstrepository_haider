
# Numpy - is a python library used for working with arrays.

# check version of numpy

import numpy as np
print(np.__version__)


#__________________BEST OF LUCK ____________________#






















