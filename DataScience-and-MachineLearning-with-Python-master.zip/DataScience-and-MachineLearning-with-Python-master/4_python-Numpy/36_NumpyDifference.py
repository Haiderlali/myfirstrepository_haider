
# Difference : Use diff() function for finding the difference
#example : [1, 2 ,3 , 4] , the descrete difference of this would be [ 2-1 , 3-2 , 4-3] = [1 , 1 , 1] by using diff():

import numpy as np
x = np.array([10 , 15 , 25 , 5])
xnew =np.diff(x)
print(xnew)


#__________________BEST OF LUCK ____________________#