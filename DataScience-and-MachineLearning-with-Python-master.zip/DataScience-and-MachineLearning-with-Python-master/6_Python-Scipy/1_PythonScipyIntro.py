
# Scipy is a scientific computation libraray that uses numpy underneath.It stand for Scientific python and providing more utilities functions for optimization , stats and signal processing.

import scipy as sp
print(sp.__version__)



#__________________BEST OF LUCK ____________________#