def greeting(name):
    print("Hello , " + name)

person1 = {
    "Name" : "Wajahat",
    "Age" : 20,
    "Subject" : "COMPUTER SCIENCE"
}
