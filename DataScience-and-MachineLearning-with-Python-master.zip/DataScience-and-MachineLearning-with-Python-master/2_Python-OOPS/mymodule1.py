
person1 = {
    "Name" : "Wajahat",
    "Age" : 20,
    "Subject" : "COMPUTER SCIENCE"
}



