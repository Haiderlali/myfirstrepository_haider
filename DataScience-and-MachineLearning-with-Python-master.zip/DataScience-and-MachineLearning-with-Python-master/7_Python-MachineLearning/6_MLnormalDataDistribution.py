
# Normal Data Dist: In numpy probability theory this kind of data dist is called normal data dist or Guassian Data Dist, where the values are concentrated around a given value.

# Rxample of normal Data dist:

import numpy as np
import matplotlib.pyplot as plt
wajahat = np.random.normal(5.0 , 1.0 , 100000)
plt.hist(wajahat , 100)
plt.show()
# A normal data dist is also know as bell curve because of its bell curve.


#__________________BEST OF LUCK ____________________#
