# Machine Learning is making the computer to learn from studying data and statistics.This is a program that analyses data and learn to predict the outcomes.

# Where to start ? Here for calculation of important numbers based on data sets we use mathematics and for studying statistics, and using the various python modules.
#Data set : [99 , 86 , 87 , 88 , 111 , 86 , 103 , 87 , 83 , 85 , 96 , 92 , 75]

# Datatype: there are three types of main category of data types in ML:

# Numerical : 1) Discrete data -numbers that are limited to integers like numbers of cars  passing by a road. 2) Continuous Data - numbers that are infinite value like price of an item.

# Categorical data: the value that cannot be count or measured like color ("yes" or "no").

# Ordinal data: these are like categorical data but can be measured or countable  like school grades where A is better than B:


#__________________BEST OF LUCK ____________________#